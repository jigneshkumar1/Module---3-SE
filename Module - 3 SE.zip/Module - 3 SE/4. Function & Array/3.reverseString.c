// 3. WAP to find reverse of string using recursion

//#include<stdio.h>
//#include<string.h>
//int main() {
//	char s[50], r[50];
//	int i, count = 0;
//	printf("Enter your string: ");
//	scanf("%s", &s);
//	
//	int length = strlen(s) - 1;
//	
//	for (i = length; i >= 0; i--) {
//		r[count] = s[i];
//		count++;
//	}
//	printf("Reversed: %s", r);
//	return 0;
//}




