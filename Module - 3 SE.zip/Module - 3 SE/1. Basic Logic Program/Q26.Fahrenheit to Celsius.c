//26. Convert temperature Fahrenheit to Celsius
#include <stdio.h>
int main()
{
	int f;
  printf("Enter a Fahrenheit : ");
  scanf("%d",&f);
  printf(" Celsius : %d ", (f-32)* 5/9 );

	
	
	return 0;
}
