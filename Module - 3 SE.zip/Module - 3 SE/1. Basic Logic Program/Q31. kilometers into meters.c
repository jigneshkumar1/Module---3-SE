//31. Convert kilometers into meters 
#include <stdio.h>
int main ()
{
	int k;
	printf("Enter a kilometer : ");
	scanf("%d",&k);
	printf("kilometer to meters %d",k*1000);
	return 0;
}
