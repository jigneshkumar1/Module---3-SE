//11. Find circumference of square formula : C = 4 * a 
#include<stdio.h>
int main(){
	int a;
	printf("enter a value : ");
	scanf("%d",&a);
	printf("circumference of square: %d",4*a);
	return 0;
} 
