//Find Area of Square formula : a = a2

#include<stdio.h>
int main (){
	
int a;
	printf("enter a value: ");
	scanf("%d",&a);
	printf("Area of square :- %d",a*a);	
	return 0;
}



