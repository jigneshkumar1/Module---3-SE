//29. Convert minutes into seconds and hours 
#include <stdio.h>
int main()
{
	int minute;
  printf("Enter a minutes : ");
  scanf("%d",&minute);
  printf("convert minute to seconde : %d",minute*60);
  	int minutes;
  printf("\nEnter a minutes : ");
  scanf("%d",&minutes);
   printf("\nconvert minute to hours: %d",minutes/60);
	

	return 0;
}
