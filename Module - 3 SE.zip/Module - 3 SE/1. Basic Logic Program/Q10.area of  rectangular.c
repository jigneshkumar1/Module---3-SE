//10. find the area of a rectangular prism formula : A=2(wl+hl+hw) 
#include<stdio.h>
int main()
{
	float l,w,h;
	printf("enter value of l : ");
	scanf("%f",&l);
		printf("\nenter value of w : ");
			scanf("%f",&w);
			printf("\nenter value of h : ");
			
		
			scanf("%f",&h);
			printf("\ncircumference of Triangle : %f",2 * (w * l + h * l + h * w));
	
	
	return 0;
}
