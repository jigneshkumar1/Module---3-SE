//6. Find area of Triangle Formula : A = 1/2 � b � h
 #include <stdio.h>
 int main()
 {
 	float b,h;
 	printf("enter a (base): ");
 	scanf("%f",&b);
 	printf("enter a (height): ");
 	scanf("%f",&h);
 	printf("area of triangle : %f",0.5* b*h);
 	
 	
 	return 0;
 }
