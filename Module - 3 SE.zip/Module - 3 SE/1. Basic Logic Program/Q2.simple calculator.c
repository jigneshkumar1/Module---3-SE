//2. Write a program to make Simple calculator (to make addition, subtraction, 
//multiplication, division and modulo) 
#include<stdio.h>
int main(){
	int x=50,y=25;
	printf("%d", x+y);
	printf("\n%d", x-y);
	printf("\n%d", x*y);
	printf("\n%d", x/y);
	printf("\n%d", x%y);

	
	return 0;
}
 


