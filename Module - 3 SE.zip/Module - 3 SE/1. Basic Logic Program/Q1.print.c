//1. Display This Information using printf 
//a. Your Name 
//b. Your Birth date 
//c. Your Age 
//d. Your Address
#include <stdio.h>
 int main (){
 	
 	printf("Name:Jignesh kumar");
 	printf("\nDob:03-02-2000");
 	printf("\nAge:24");
 	printf("\nAdd.Pali,(Rajasthan)");
 	
 
 	return 0;
 	
 }
 
 
 

