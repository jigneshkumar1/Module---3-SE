//9. Find circumference of Triangle formula : triangle = a + b + c 
#include<stdio.h>
int main()
{
	int a,b,c;
	printf("enter value of a : ");
	scanf("%d",&a);
		printf("\nenter value of b : ");
			scanf("%d",&b);
			printf("\nenter value of c : ");
			
		
			scanf("%d",&c);
			printf("\ncircumference of Triangle : %d",a+b+c);
	
	
	return 0;
}
