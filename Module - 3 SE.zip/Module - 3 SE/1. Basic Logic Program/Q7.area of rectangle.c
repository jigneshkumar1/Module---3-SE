//7. Find area of Rectangle Formula : A=wl 

#include<stdio.h>
int main(){
	int w,l;
	printf("enter a length: ");scanf("%d",&l);
	printf("enter a width: ");scanf("%d",&w);
	printf("Area of Rectangle : %d",l*w);
	
	
	
	return 0;
}

