//3. WAP to Find Area And Circumference of Circle
#include<stdio.h>
int main()
{
	float c,a;
	printf("enter a circumference value : ");
	scanf("%f",&c);
	printf("enter a area value : ");
	scanf("%f",&a);
    printf("circumference of circle : %f",2*3.14*c); 
	printf("\narea of circle : %f",3.14*a*a);
	return 0;
 } 
