//13. Find character value from ascii 



#include<stdio.h>
int main ()
{
	char ch;
	printf ("enter a character : ");
	scanf ("%c",&ch);
	printf("Ascii value = %d",ch);
	
	
}
