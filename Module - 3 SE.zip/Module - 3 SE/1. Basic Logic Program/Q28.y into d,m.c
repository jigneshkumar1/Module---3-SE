//28. Convert years into days and months 

#include <stdio.h>
int main()
{
	int years;
  printf("Enter a years : ");
  scanf("%d",&years);
  printf("convert years into days  : %d",years*365);
  
	int year;
  printf("\nEnter a years : ");
  scanf("%d",&year);
 printf("convert years into month : %d",year*12);

	
	return 0;
}
