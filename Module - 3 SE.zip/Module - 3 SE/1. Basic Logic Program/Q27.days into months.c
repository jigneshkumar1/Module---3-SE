//27. Convert days into months
#include <stdio.h>
int main()
{
	int days;
  printf("Enter a days : ");
  scanf("%d",&days);
  printf("convert days to month  : %d",days/30);

	
	
	return 0;
}
