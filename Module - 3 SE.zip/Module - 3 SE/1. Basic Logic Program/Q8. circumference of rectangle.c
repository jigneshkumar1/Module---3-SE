//8. Find circumference of Rectangle formula : C = 4 * a
#include<stdio.h>
int main(){
	int a;
	printf("enter a value : ");
	scanf("%d",&a);
	printf("circumference of Rectangle : %d",4*a);
	return 0;
} 
