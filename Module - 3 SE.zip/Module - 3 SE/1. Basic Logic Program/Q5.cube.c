//5. Find Area of Cube formula : a = 6a2 

#include<stdio.h>
int main (){
	
	int a;
	printf("enter a value: ");
	scanf("%d",&a);
	printf("Area of cube:- %d",6*a*a);	
	return 0;
}
